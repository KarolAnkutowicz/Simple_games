#include <chrono>
#include <thread>

#pragma once

class cTiming
{
public:
	inline int getOpenHour() { return vOpenHour; }
	inline int getCloseHour() { return vCloseHour; }
	inline int getOpenDay() { return vOpenDay; }
	inline int getCloseDay() { return vCloseDay; }

	tm getCurrentTime();
	bool mUsedCarDealerIsOpen();

private:
	const int vOpenHour = 10;
	const int vCloseHour = 24;
	const int vOpenDay = 1;
	const int vCloseDay = 6;
};
