#include "cListCar.hpp"

bool cListCar::mAnyAvailableCar()
{
	if (vAvailableCars.size() == 0)
		return false;
	return true;
}

bool cListCar::mCheckAvailableCarsIndex(unsigned int aIndex)
{
	if (aIndex > vAvailableCars.size())
		return false;
	return true;
}

void cListCar::mSellOrEraseCar(cTiming& aTime, unsigned int aIndex, bool aIfSale)
{
	if (aIfSale == true)
	{
		vAvailableCars[aIndex].setTimeSold(aTime);
		vSoldCars.push_back(vAvailableCars[aIndex]);
	}
	std::vector<cCar> vTemporaryAvailableCars;
	for (unsigned int i = 0; i < aIndex; i++)
		vTemporaryAvailableCars.push_back(vAvailableCars[i]);
	for (unsigned int i = aIndex + 1; i < vAvailableCars.size(); i++)
		vTemporaryAvailableCars.push_back(vAvailableCars[i]);
	do
	{
		vAvailableCars.pop_back();
	} while (vAvailableCars.size() != 0);
	for (unsigned int i = 0; i < vTemporaryAvailableCars.size(); i++)
		vAvailableCars.push_back(vTemporaryAvailableCars[i]);
}
