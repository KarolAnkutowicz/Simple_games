#include "cFileOperations.hpp"
#include <fstream>
#include <iomanip>

void cFileOperations::mReadAvailableCars(cListCar& aListCar, cTiming& aTime)
{
	std::ifstream strIn;
	strIn.open("./files/available_cars.txt");
	if (strIn.is_open() == true)
	{
		char vName[conNameSize];
		char vRegistration[conRegiSize];
		double vStartingPrice, vCurrentPrice;
		unsigned int vDay, vMonth, vYear, vHour, vMinute, vSecond;
		char c;
		do
		{
			strIn >> vName >> vRegistration >> vStartingPrice >> vCurrentPrice;
			cCar Car(vName, vRegistration, vStartingPrice, aTime);
			strIn >> vDay >> c >> vMonth >> c >> vYear;
			Car.setTimeAddDay(vDay);
			Car.setTimeAddMonth(vMonth - 1);
			Car.setTimeAddYear(vYear - 1900);
			strIn >> vHour >> c >> vMinute >> c >> vSecond;
			Car.setTimeAddHour(vHour);
			Car.setTimeAddMinute(vMinute);
			Car.setTimeAddSecond(vSecond);
			aListCar.vAvailableCars.push_back(Car);
		} while (!EOF);
	}
	strIn.close();
}

void cFileOperations::mSaveAvailableCars(cListCar& aCar)
{
	std::ofstream strOut;
	strOut.open("./files/available_cars.txt");
	if (strOut.is_open() == true)
	{
		strOut.clear();
		for (unsigned int i = 0; i < aCar.vAvailableCars.size(); i++)
		{
			strOut << aCar.vAvailableCars[i].getName() << " " << aCar.vAvailableCars[i].getRegistration() << " "
				<< aCar.vAvailableCars[i].getStartingPrice() << " " << aCar.vAvailableCars[i].getCurrentPrice() << " "
				<< aCar.vAvailableCars[i].getTimeAdd().tm_mday << "." << aCar.vAvailableCars[i].getTimeAdd().tm_mon + 1
				<< "." << aCar.vAvailableCars[i].getTimeAdd().tm_year + 1900 << " " << aCar.vAvailableCars[i].getTimeAdd().tm_hour
				<< ":" << aCar.vAvailableCars[i].getTimeAdd().tm_min << ":" << aCar.vAvailableCars[i].getTimeAdd().tm_sec << "\n";
		}
	}
	strOut.close();
}
