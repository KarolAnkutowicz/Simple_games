#include "cPrinter.hpp"
#include "cTiming.hpp"
#include <iomanip>

void cPrinter::mPrintTime(tm aTime)
{
	std::cout << aTime.tm_mday << "." << aTime.tm_mon + 1 << "." << aTime.tm_year + 1900 << " "
		<< aTime.tm_hour << ":" << aTime.tm_min << ":" << aTime.tm_sec;
}

void cPrinter::mPrintOpeningHours(cTiming& aTime)
{
	std::cout << "Opening hours: ";
	int vDays[2] = { aTime.getOpenDay(), aTime.getCloseDay() };
	for (int i = 0; i < 2; i++)
	{
		switch (vDays[i])
		{
		case 0: std::cout << "Sunday "; break;
		case 1: std::cout << "Monday "; break;
		case 2: std::cout << "Tuesday "; break;
		case 3: std::cout << "Wednesday "; break;
		case 4: std::cout << "Thursday "; break;
		case 5: std::cout << "Friday "; break;
		case 6: std::cout << "Saturday "; break;
		}
		if (i == 0)
			std::cout << "- ";
	}
	int vHours[2] = { aTime.getOpenHour(), aTime.getCloseHour() };
	for (int i = 0; i < 2; i++)
	{
		if (vHours[i] < 10)
			std::cout << "0";
		std::cout << vHours[i] << ":00";
		if (i == 0)
			std::cout << "-";
		if (i == 1)
			std::cout << "\n";
	}
}

void cPrinter::mPrintOpenOrClose(cTiming& Time)
{
	std::cout << "Using car dealer is ";
	if (Time.mUsedCarDealerIsOpen() == true)
		std::cout << "open";
	else
		std::cout << "close! You don't add and sale cars";
	std::cout << "!\n";
}

void cPrinter::mPrintTimeNow(cTiming& aTime)
{
	std::cout << "Today: ";
	switch (aTime.getCurrentTime().tm_wday)
	{
	case 0: std::cout << "Sunday "; break;
	case 1: std::cout << "Monday "; break;
	case 2: std::cout << "Tuesday "; break;
	case 3: std::cout << "Wednesday "; break;
	case 4: std::cout << "Thursday "; break;
	case 5: std::cout << "Friday "; break;
	case 6: std::cout << "Saturday "; break;
	}
	if (aTime.getCurrentTime().tm_mday < 10)
		std::cout << "0";
	std::cout << aTime.getCurrentTime().tm_mday << ".";
	if (aTime.getCurrentTime().tm_mon + 1 < 10)
		std::cout << "0";
	std::cout << aTime.getCurrentTime().tm_mon + 1 << "." << aTime.getCurrentTime().tm_year + 1900 << " ";
	if (aTime.getCurrentTime().tm_hour < 10)
		std::cout << "0";
	std::cout << aTime.getCurrentTime().tm_hour << ":";
	if (aTime.getCurrentTime().tm_min < 10)
		std::cout << "0";
	std::cout << aTime.getCurrentTime().tm_min << ":";
	if (aTime.getCurrentTime().tm_sec < 10)
		std::cout << "0";
	std::cout << aTime.getCurrentTime().tm_sec << "\n";
}

void cPrinter::mPrintMenu(bool aIsOpen)
{
	if (aIsOpen == true)
		std::cout << "\n (1) - Add car\n (2) - Sale car";
	std::cout << "\n (3) - Erase car\n (4) - Print available cars\n (5) - Print sold cars\n (6) - Print today summary\n (e) - exit\n";
}

void cPrinter::mPrintSaleEraseCarConfirm(cListCar& ListCar, unsigned int aIndex, bool aSale)
{
	std::cout << "\nYou want ";
	if (aSale == true)
		std::cout << "sale";
	else
		std::cout << "erase";
	std::cout << " this car:\n" << ListCar.vAvailableCars[aIndex].getName() << " "
		<< ListCar.vAvailableCars[aIndex].getRegistration() << " " << ListCar.vAvailableCars[aIndex].getCurrentPrice() << "\n";
}

void cPrinter::mPrintAvailableCars(cListCar& ListCar, cTiming& aTime)
{
	std::cout << "\nAvailable cars:\n\n";
	if (ListCar.vAvailableCars.empty())
		std::cout << " No available cars!\n\n";
	else
	{
		std::cout << "   No                     Model Registration Start_price Current_price   Term_add\n";
		for (int i = 0; i < ListCar.vAvailableCars.size(); i++)
		{
			ListCar.vAvailableCars[i].mUpdateCurrentPrice(aTime);
			std::cout << std::setw(5) << i << std::setw(conNameSize + 1) << ListCar.vAvailableCars[i].getName() << " "
				<< std::setw(conRegiSize + 1) << ListCar.vAvailableCars[i].getRegistration() << " "
				<< std::setw(10) << ListCar.vAvailableCars[i].getStartingPrice() << " "
				<< std::setw(10) << ListCar.vAvailableCars[i].getCurrentPrice() << "  ";
			mPrintTime(ListCar.vAvailableCars[i].getTimeAdd());
			std::cout << "\n";
		}
	}
}

void cPrinter::mPrintSoldCarsToday(cListCar& ListCar, cTiming& aTime)
{
	std::cout << "\nSold cars today:\n\n";
	if (ListCar.vSoldCars.empty())
		std::cout << " No sold cars!\n\n";
	else
	{
		std::cout << "   No                     Model Registration Start_price Sold_price   Term_add           Term_sold\n";
		for (int i = 0; i < ListCar.vSoldCars.size(); i++)
		{
			std::cout << std::setw(5) << i << std::setw(conNameSize + 1) << ListCar.vSoldCars[i].getName() << " "
				<< std::setw(conRegiSize + 1) << ListCar.vSoldCars[i].getRegistration() << " "
				<< std::setw(10) << ListCar.vSoldCars[i].getStartingPrice() << " "
				<< std::setw(10) << ListCar.vSoldCars[i].getCurrentPrice() << "  ";
			mPrintTime(ListCar.vSoldCars[i].getTimeAdd());
			std::cout << "  ";
			mPrintTime(ListCar.vSoldCars[i].getTimeSold());
			std::cout << "\n";
		}
	}
}

void cPrinter::mPrintSummaryToday(cListCar& ListCar, cTiming& aTime)
{
	std::cout << "Today summary:\n\n";
	mPrintAvailableCars(ListCar, aTime);
	mPrintSoldCarsToday(ListCar, aTime);
}
