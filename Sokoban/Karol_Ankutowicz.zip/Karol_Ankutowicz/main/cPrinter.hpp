#include "cCar.hpp"
#include "cListCar.hpp"
#include "cTiming.hpp"
#include <iostream>

#pragma once

class cPrinter
{
public:
	void mPrintTime(tm aTime);
	void mPrintOpeningHours(cTiming& aTime);
	void mPrintOpenOrClose(cTiming& Time);
	void mPrintTimeNow(cTiming& aTime);

	void mPrintMenu(bool aIsOpen);

	inline void mPrintAddCar() { std::cout << "Add car menu\n\n"; }
	inline void mPrintAddCarModel() { std::cout << "Please give name a model (max " << conNameSize << " characters, \"_\" is separator): "; }
	inline void mPrintAddCarRegistration() { std::cout << "Please give registration (max " << conRegiSize << " characters, \"_\" is separator): "; }
	inline void mPrintAddCarPrice() { std::cout << "Please give price: "; }
	inline void mPrintAddCarExist() { std::cout << "This car be on the list\n"; }
	inline void mPrintAddCarConfirm() { std::cout << "Are you sure add this car?\n\n (y)es\n"; }
	inline void mPrintAddCarFinalAdd() { std::cout << "\nCar added to list\n\n"; }
	inline void mPrintAddCarFinalNotAdd() { std::cout << "\nCar not added to list\n\n"; }

	inline void mPrintSaleCar() { std::cout << "Sale car menu\n\n"; }
	inline void mPrintSaleCarIndex() { std::cout << "Please give number of car position on the list: "; }
	inline void mPrintSaleCarConfirm() { std::cout << "Are you sure sale this car?\n\n (y)es\n"; }
	inline void mPrintSaleCarFinalSold() { std::cout << "\nCar sold\n\n"; }
	inline void mPrintSaleCarFinalNotSold() { std::cout << "\nCar not sold\n\n"; }

	inline void mPrintAvailableCarWrongIndex() { std::cout << "Index not exist\n"; }
	void mPrintSaleEraseCarConfirm(cListCar& ListCar, unsigned int aIndex, bool aSale);

	inline void mPrintEraseCar() { std::cout << "Erase car menu\n\n"; }
	inline void mPrintEraseCarIndex() { std::cout << "Please give number of car position on the list: "; }
	inline void mPrintEraseCarConfirm() { std::cout << "Are you sure erase this car?\n\n(y)es\n"; }
	inline void mPrintEraseCarFinalErase() { std::cout << "\nCar erase\n\n"; }
	inline void mPrintEraseCarFinalNotErase() { std::cout << "\nCar not erase\n\n"; }

	void mPrintAvailableCars(cListCar& ListCar, cTiming& aTime);
	
	void mPrintSoldCarsToday(cListCar& ListCar, cTiming& aTime);

	void mPrintSummaryToday(cListCar& ListCar, cTiming& aTime);

	inline void mPrintExit() { std::cout << "Quit the program. Are you sure?\n\n(y)es\n"; }
};
