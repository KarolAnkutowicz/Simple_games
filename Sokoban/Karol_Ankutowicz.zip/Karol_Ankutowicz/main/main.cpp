﻿#include "cCar.hpp"
#include "cFileOperations.hpp"
#include "cListCar.hpp"
#include "cPrinter.hpp"
#include "cTiming.hpp"

int main()
{
    cTiming Time;
    cPrinter Print;
    cListCar ListCar;
    cFileOperations FileOperations;
    bool vIsOpen = Time.mUsedCarDealerIsOpen();
    ListCar.vAvailableCars.clear();
    ListCar.vSoldCars.clear();
    FileOperations.mReadAvailableCars(ListCar, Time);

    char vOption;
    bool vEndProgram = false;

    char vName[conNameSize];
    char vRegistration[conRegiSize];
    double vStartingPrice;
    unsigned int vIndex;

    do
    {
        system("cls");
        Print.mPrintOpenOrClose(Time);
        Print.mPrintOpeningHours(Time);
        Print.mPrintTimeNow(Time);
        Print.mPrintMenu(vIsOpen);
        std::cin >> vOption;
        switch (vOption)
        {
        case '1':
            if (vIsOpen == true)
            {
                system("cls");
                Print.mPrintAddCar();
                Print.mPrintAddCarModel();
                std::cin >> vName;
                Print.mPrintAddCarRegistration();
                std::cin >> vRegistration;
                Print.mPrintAddCarPrice();
                std::cin >> vStartingPrice;
                cCar Car(vName, vRegistration, vStartingPrice, Time);
                Print.mPrintAddCarConfirm();
                std::cin >> vOption;
                if (vOption == 'y')
                {
                    ListCar.mAddCar(Car);
                    Print.mPrintAddCarFinalAdd();
                }
                else
                    Print.mPrintAddCarFinalNotAdd();
                system("pause");
            }
            break;
        case '2':
            if (vIsOpen == true)
            {
                system("cls");
                Print.mPrintSaleCar();
                Print.mPrintAvailableCars(ListCar, Time);
                if (ListCar.mAnyAvailableCar() == true)
                {
                    Print.mPrintSaleCarIndex();
                    std::cin >> vIndex;
                    if (ListCar.mCheckAvailableCarsIndex(vIndex) == false)
                    {
                        Print.mPrintAvailableCarWrongIndex();
                        Print.mPrintSaleCarFinalNotSold();
                    }
                    else
                    {
                        Print.mPrintSaleEraseCarConfirm(ListCar, vIndex, true);
                        Print.mPrintSaleCarConfirm();
                        std::cin >> vOption;
                        if (vOption == 'y')
                        {
                            ListCar.mSellOrEraseCar(Time, vIndex, true);
                            Print.mPrintSaleCarFinalSold();
                        }
                        else
                            Print.mPrintSaleCarFinalNotSold();
                    }
                }
                system("pause");
            }
            break;
        case '3':
            system("cls");
            Print.mPrintEraseCar();
            Print.mPrintAvailableCars(ListCar, Time);
            if (ListCar.mAnyAvailableCar() == true)
            {
                Print.mPrintEraseCarIndex();
                std::cin >> vIndex;
                if (ListCar.mCheckAvailableCarsIndex(vIndex) == false)
                {
                    Print.mPrintAvailableCarWrongIndex();
                    Print.mPrintEraseCarFinalNotErase();
                }
                else
                {
                    Print.mPrintSaleEraseCarConfirm(ListCar, vIndex, false);
                    Print.mPrintEraseCarConfirm();
                    std::cin >> vOption;
                    if (vOption == 'y')
                    {
                        ListCar.mSellOrEraseCar(Time, vIndex, false);
                        Print.mPrintEraseCarFinalErase();
                    }
                    else
                        Print.mPrintEraseCarFinalNotErase();
                }
            }
            system("pause");
            break;
        case '4':
            system("cls");
            Print.mPrintAvailableCars(ListCar, Time);
            system("pause");
            break;
        case '5':
            system("cls");
            Print.mPrintSoldCarsToday(ListCar, Time);
            system("pause");
            break;
        case '6':
            system("cls");
            Print.mPrintSummaryToday(ListCar, Time);
            system("pause");
            break;
        case 'e':
            system("cls");
            Print.mPrintExit();
            std::cin >> vOption;
            if (vOption == 'y')
                vEndProgram = true;
            break;
        }
    } while (vEndProgram == false);
    FileOperations.mSaveAvailableCars(ListCar);

    return 0;
}
