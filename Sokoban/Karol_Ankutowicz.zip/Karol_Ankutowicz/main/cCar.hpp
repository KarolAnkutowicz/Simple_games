#include "cTiming.hpp"
#include <iostream>

#pragma once

const unsigned int conNameSize = 25;
const unsigned int conRegiSize = 10;

class cCar
{
public:
	cCar(const char aName[conNameSize], const char aRegistration[conRegiSize], const double aStartingPrice, cTiming& aTime)
	{
		strcpy_s(vName, aName);
		strcpy_s(vRegistration, aRegistration);
		vStartingPrice = vCurrentPrice = aStartingPrice;
		vTimeAdd = aTime.getCurrentTime();
		vTimeSold = aTime.getCurrentTime();
	};

	inline const char* getName() { return vName; }
	inline const char* getRegistration() { return vRegistration; }
	inline const double getStartingPrice() { return vStartingPrice; }
	inline double getCurrentPrice() { return vCurrentPrice; }
	inline tm getTimeAdd() { return vTimeAdd; }
	inline tm getTimeSold() { return vTimeSold; }

	inline void setTimeAddDay(unsigned int aDay) { vTimeAdd.tm_mday = aDay; }
	inline void setTimeAddMonth(unsigned int aMonth) { vTimeAdd.tm_mon = aMonth; }
	inline void setTimeAddYear(unsigned int aYear) { vTimeAdd.tm_year = aYear; }
	inline void setTimeAddHour(unsigned int aHour) { vTimeAdd.tm_hour = aHour; }
	inline void setTimeAddMinute(unsigned int aMinute) { vTimeAdd.tm_min = aMinute; }
	inline void setTimeAddSecond(unsigned int aSecond) { vTimeAdd.tm_sec = aSecond; }

	inline void setTimeSold(cTiming& aTime) { vTimeSold = aTime.getCurrentTime(); }

	void mUpdateCurrentPrice(cTiming& aTime);

private:
	char vName[conNameSize];
	char vRegistration[conRegiSize];
	double vStartingPrice;
	double vCurrentPrice;
	tm vTimeAdd;
	tm vTimeSold;
};

