#include "cTiming.hpp"

tm cTiming::getCurrentTime()
{
	struct tm vCurrentTime;
	__time32_t vClock;

	_time32(&vClock);
	_localtime32_s(&vCurrentTime, &vClock);
	return vCurrentTime;
}

bool cTiming::mUsedCarDealerIsOpen()
{
	if (getCurrentTime().tm_wday >= vOpenDay && getCurrentTime().tm_wday <= vCloseDay
		&& getCurrentTime().tm_hour >= vOpenHour && getCurrentTime().tm_hour < vCloseHour)
		return true;
	return false;
}
