#include "cCar.hpp"
#include <cmath>

void cCar::mUpdateCurrentPrice(cTiming& aTime)
{
	double vCurrentSeconds, vAddSeconds, vDifferenceSeconds;
	if (abs(aTime.getCurrentTime().tm_year - vTimeAdd.tm_year) >= 2)
		vCurrentPrice = 0.8 * vStartingPrice;
	else if (abs(aTime.getCurrentTime().tm_year - vTimeAdd.tm_year) < 2 && abs(aTime.getCurrentTime().tm_mon - vTimeAdd.tm_mon) >= 2)
		vCurrentPrice = 0.8 * vStartingPrice;
	else if (abs(aTime.getCurrentTime().tm_mon - vTimeAdd.tm_mon) < 2 && abs(aTime.getCurrentTime().tm_mday - vTimeAdd.tm_mday) >= 2)
		vCurrentPrice = 0.8 * vStartingPrice;
	else if (abs(aTime.getCurrentTime().tm_mday - vTimeAdd.tm_mday) < 2 && abs(aTime.getCurrentTime().tm_hour - vTimeAdd.tm_hour) >= 2)
		vCurrentPrice = 0.8 * vStartingPrice;
	else
	{
		vCurrentSeconds = aTime.getCurrentTime().tm_hour * 3600 + aTime.getCurrentTime().tm_min * 60 + aTime.getCurrentTime().tm_sec;
		vAddSeconds = vTimeAdd.tm_hour * 3600 + vTimeAdd.tm_min * 60 + vTimeAdd.tm_sec;
		vDifferenceSeconds = abs(vCurrentSeconds - vAddSeconds);
		if (vDifferenceSeconds <= 30)
			vCurrentPrice = vStartingPrice;
		else if (vDifferenceSeconds > 30 && vDifferenceSeconds <= 2030)
			vCurrentPrice = vStartingPrice * (10030 - round(vDifferenceSeconds/10) * 10) / 10000;
		else
			vCurrentPrice = 0.8 * vStartingPrice;
	}
}
