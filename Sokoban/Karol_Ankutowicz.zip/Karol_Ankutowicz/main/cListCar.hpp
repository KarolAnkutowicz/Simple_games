#include "cCar.hpp"
#include "cTiming.hpp"
#include <vector>

#pragma once

class cListCar
{
public:
	std::vector<cCar> vAvailableCars;
	std::vector<cCar> vSoldCars;

	bool mAnyAvailableCar();
	bool mCheckAvailableCarsIndex(unsigned int aIndex);

	inline void mAddCar(cCar aCar) { vAvailableCars.push_back(aCar); }
	void mSellOrEraseCar(cTiming& aTime, unsigned int aIndex, bool aIfSale);
};
