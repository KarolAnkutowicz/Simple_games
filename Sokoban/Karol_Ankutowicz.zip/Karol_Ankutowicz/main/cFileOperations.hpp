#include "cCar.hpp"
#include "cListCar.hpp"
#include "cTiming.hpp"
#include <fstream>

#pragma once

class cFileOperations
{
public:
	void mReadAvailableCars(cListCar& aCar, cTiming& aTime);

	void mSaveAvailableCars(cListCar& aCar);
};

